using System.Text.Json;
using System.Text.Json.Serialization;

namespace ReceiverNet.Models;

/// <summary>
/// Inbound event envelope. Port of ResultEventIn in cart_platform/receiver/app.py.
/// </summary>
public sealed class ResultEventIn
{
    [JsonPropertyName("event_id")]
    public string EventId { get; set; } = string.Empty;

    [JsonPropertyName("event_type")]
    public string EventType { get; set; } = string.Empty;

    [JsonPropertyName("payload")]
    public JsonElement Payload { get; set; }

    [JsonPropertyName("schema_version")]
    public int SchemaVersion { get; set; } = 1;

    [JsonPropertyName("occurred_at")]
    public string? OccurredAt { get; set; }

    [JsonPropertyName("entity_id")]
    public string? EntityId { get; set; }

    [JsonPropertyName("site_key")]
    public string? SiteKey { get; set; }

    [JsonPropertyName("upload_id")]
    public string? UploadId { get; set; }

    [JsonPropertyName("job_id")]
    public string? JobId { get; set; }

    [JsonPropertyName("model_id")]
    public string? ModelId { get; set; }

    /// <summary>
    /// Contract validation equivalent to the pydantic field constraints.
    /// Returns null when valid, otherwise the error message.
    /// </summary>
    public string? Validate()
    {
        if (string.IsNullOrWhiteSpace(EventId))
            return "event_id is required";
        if (EventId.Length > 512)
            return "event_id exceeds the 512 character contract limit";
        if (EventId.Length > 450)
            return "event_id exceeds 450 characters, the storage key limit";
        if (string.IsNullOrWhiteSpace(EventType))
            return "event_type is required";
        if (Payload.ValueKind != JsonValueKind.Object)
            return "payload must be a JSON object";
        return null;
    }
}
