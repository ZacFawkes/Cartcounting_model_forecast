using Microsoft.AspNetCore.Mvc;

namespace ReceiverNet.Models;

/// <summary>
/// Query-string filters shared by the list routes. Names are snake_case to stay
/// wire-compatible with the Python receiver.
/// </summary>
public sealed class ResultQuery
{
    [FromQuery(Name = "entity_id")] public string? EntityId { get; set; }
    [FromQuery(Name = "site_key")] public string? SiteKey { get; set; }
    [FromQuery(Name = "upload_id")] public string? UploadId { get; set; }
    [FromQuery(Name = "job_id")] public string? JobId { get; set; }
    [FromQuery(Name = "model_id")] public string? ModelId { get; set; }
    [FromQuery(Name = "status")] public string? Status { get; set; }

    /// <summary>calibration only.</summary>
    [FromQuery(Name = "scope")] public string? Scope { get; set; }

    /// <summary>backtest only.</summary>
    [FromQuery(Name = "backtest_type")] public string? BacktestType { get; set; }

    /// <summary>Inclusive lower bound on the ordering timestamp (ISO-8601).</summary>
    [FromQuery(Name = "since")] public string? Since { get; set; }

    /// <summary>Inclusive upper bound on the ordering timestamp (ISO-8601).</summary>
    [FromQuery(Name = "until")] public string? Until { get; set; }

    [FromQuery(Name = "limit")] public int? Limit { get; set; }
    [FromQuery(Name = "offset")] public int? Offset { get; set; }
}
