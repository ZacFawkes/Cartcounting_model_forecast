using System.Text.Json.Serialization;

namespace ReceiverNet.Models;

/// <summary>Outcome of an idempotent store attempt.</summary>
public enum StoreOutcome
{
    /// <summary>First time this event_id was seen. HTTP 201.</summary>
    Created,

    /// <summary>Same event_id, byte-identical payload. HTTP 200.</summary>
    Replay,

    /// <summary>Same event_id, different payload. HTTP 409 - never overwritten.</summary>
    Conflict
}

/// <summary>Acknowledgement returned by the four write routes.</summary>
public sealed class StoreAck
{
    [JsonPropertyName("event_id")]
    public string EventId { get; set; } = string.Empty;

    /// <summary>"created" or "replay".</summary>
    [JsonPropertyName("outcome")]
    public string Outcome { get; set; } = string.Empty;

    [JsonPropertyName("stored_record")]
    public Dictionary<string, object?> StoredRecord { get; set; } = new();
}

/// <summary>Paged list response. Port of PageOut.</summary>
public sealed class PageOut
{
    [JsonPropertyName("total")]
    public int Total { get; set; }

    [JsonPropertyName("limit")]
    public int Limit { get; set; }

    [JsonPropertyName("offset")]
    public int Offset { get; set; }

    [JsonPropertyName("items")]
    public IReadOnlyList<Dictionary<string, object?>> Items { get; set; } =
        Array.Empty<Dictionary<string, object?>>();
}
